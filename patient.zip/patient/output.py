Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
============================= RESTART: C:\Users\EEE\AppData\Local\Programs\Python\Python312\rakesh.py =============================
Enter the number of patients: 2
Enter patient name: srujana
Enter gender: female
Enter age: 20
Enter heart rate: 120
Enter blood pressure: 100
Enter sugar level: 130
Enter patient name: rakesh
Enter gender: male
Enter age: 23
Enter heart rate: 100
Enter blood pressure: 120
Enter sugar level: 130
rakesh
srujana
patient_name	gender	age	heart_rate	blood_pressure	sugar_levels
srujana		female	20	120		100		130
rakesh		male	23	100		120		130
  patient_name  gender  age  heart_rate  blood_pressure  sugar_level
0      srujana  female   20         120             100          130
1       rakesh    male   23         100             120          130
{1}
{1}
[{'patient_name': 'rakesh', 'gender': 'male', 'age': 23, 'heart_rate': 100, 'blood_pressure': 120, 'sugar_level': 130}, {'patient_name': 'srujana', 'gender': 'female', 'age': 20, 'heart_rate': 120, 'blood_pressure': 100, 'sugar_level': 130}]
120
100
120
100
130
130
23
20
>>> 
============================= RESTART: C:\Users\EEE\AppData\Local\Programs\Python\Python312\rakesh.py =============================
